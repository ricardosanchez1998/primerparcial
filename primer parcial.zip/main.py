from funcionteca import *
from ABM import *

#a ultimo momento pase toda la funcion main() a otro archivo porque venia laburandolo en el ABM, importé el abm pero no me toma la clase.
#volvi a pasar la fx main al abm para entregarlo y que se evalue si funciona desde ahi, malisima mia chequear esto a ultimo momento

def main():
    while True:
        print ("¿Que desea hacer?")
        eleccion = menu(["Alta de producto", "Baja de producto","Listado de productos", "Modificar producto"])
        match eleccion:
            case 1: 
                Producto.alta(Producto, productos, cantidad_de_productos)
            case 2:
                Producto.baja(Producto, productos, cantidad_de_productos)
            case 3:
                Producto.mostrar_lista(Producto, productos, cantidad_de_productos)
            case 4:
                Producto.modificacion(Producto, productos, cantidad_de_productos)
            case 0:
                break


main()