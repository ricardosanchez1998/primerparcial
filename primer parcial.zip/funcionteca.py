
def get_int (msj: str):
    return int(input(msj))


def get_int_rango_reintentos (msj: str, msj_error: str, min: int, max: int, reintentos: int | None = None)  -> int | None:

    while reintentos is None or reintentos > 0 or reintentos == -1:
        numero = get_int(msj)
        retorno = None

        if numero >= min and numero <= max:
            retorno = numero
            break
        else: 
            match reintentos:
                case None:
                    break
                case -1: #Para repetir el error hasta ingresar correctamente
                    print(msj_error)
                case _: 
                    print (msj_error)
                    reintentos -= 1

    return retorno


def menu(opciones: list) -> int:
    i=0
    while i < len(opciones):
        print (f"[{i+1}] {opciones[i]}")
        i+=1

    print ("\n[0] SALIR")
    return get_int_rango_reintentos ("\n\t[OPCION]: ", "[ERROR]", 0, len (opciones), -1)


def get_string (msj: str, min: int, max: int) -> str | None:
    
    aux = input(msj)
    if validar_solo_alfabeticos(aux, min,max) == True:
        return aux

    return None
    
def validar_solo_alfabeticos (cadena:str, min: int, max: int,) -> bool:
    if cadena.isalpha() == True:
        if len(cadena) >= min and len(cadena) <= max:
            return True
    
    return False


def calcular_promedio(lista: list):
    suma = 0
    for elemento in lista:
        suma += elemento
    return suma / len(lista)

def busqueda_lineal(lista, elemento):
    for i in range (len(lista)):
        if lista [i] == elemento:
            return i
    return None

def filtrar_numeros_positivos(lista):
    lista_filtrada = list()

    for elemento in lista:
        if elemento > 0:
            lista_filtrada.append(elemento)

    return lista_filtrada

def filtrar_numeros_pares(lista):
    lista_filtrada = list()

    for elemento in lista:
        if elemento % 2 == 0:
            lista_filtrada.append(elemento)

    return lista_filtrada

def es_par(numero: int)-> int:
    if numero % 2 == 0:
        return numero


def mi_map(funcion, lista:list)->list:
    aux = []
    for i in lista:
        aux.append (funcion(i))
    return aux

def mi_reduce(lista:list,funcion):
    acumulador = lista[0]
    for i in range (len(lista)):
        acumulador = funcion(acumulador, lista [i])  

    return acumulador
    
def mi_filter(lista:list, funcion):
    aux = []
    for i in lista:
        if funcion(i) == True:
            aux.append(i)
    return aux

def get_fecha() -> str:
    print("Ingrese fecha: ")
    aaaa = get_int_rango_reintentos("\tIngrese año: ", "ERROR, reintente: ", 1, 2099, -1)
    mm = get_int_rango_reintentos("\tIngrese mes: ", "ERROR, reintente", 1, 12, -1)
    match mm:
        case 1,3,5,7,8,10,12:
            dd = get_int_rango_reintentos("\tIngresese dia: ", "ERROR, reintente", 1, 32, -1)
        case 2:
            dd = get_int_rango_reintentos("\tIngresese dia: ", "ERROR, reintente", 1, 30, -1)
        case _:
            dd = get_int_rango_reintentos("\tIngresese dia: ", "ERROR, reintente", 1, 31, -1)
    
    """aaaa = str(aaaa)
    while len(aaaa) != 4:
        aaaa."""

    fecha = str(dd)+"/"+str(mm)+"/"+str(aaaa)
    return fecha
"""
Desarrollar 6 funciones:
1 - leer_txt(path, modo)
2 - escribir_txt(path, modo, data)
3 - leer_json(path, modo)
4 - escribir_json(path, modo, data)
5- leer_csv(path, modo)
6 - escribir_csv(path, modo, data) 

import csv
import json

#path = "MOCK_EJEMPLO.json"
#data = [{{"id":11,
          "first_name":"Mav2",
          "last_name":"Kin32t",
          "email":"mkinzasdett0@multiply.com",
          "gender":"Female",
          "ip_address":"50.215.146.252"}
},
{
        "id":12,
        "first_name":"Mav2",
        "last_name":"Kin32t",
        "email":"mkinzasdett0@multiply.com",
        "gender":"Female",
        "ip_address":"50.215.146.252"
},
{
        "id":13,
        "first_name":"Mav2",
        "last_name":"Kin32t",
        "email":"mkinzasdett0@multiply.com",
        "gender":"Female",
        "ip_address":"50.215.146.252"
}]

def leer_json(path, encabezado:str):
    with open(path, 'r') as file:
        archivo = json.load(file)
        for item in archivo:
            print(item[encabezado])


#leer_json(path, "email")

def escribir_json(path, data):
    with open(path, 'w') as file:
        json.dump(data, file, indent=4)

#escribir_json(path, data)
"""