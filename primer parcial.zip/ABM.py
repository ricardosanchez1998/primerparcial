from funcionteca import *

productos = [{"Codigo":"5735-EE","Detalle":"Mont","Precio de compra":8,"Precio de venta":57,"Peso":802838},
{"Codigo":"7408-EE","Detalle":"Rosly","Precio de compra":10,"Precio de venta":60,"Peso":349185},
{"Codigo":"2849-EE","Detalle":"Adele","Precio de compra":15,"Precio de venta":69,"Peso":207904},
{"Codigo":"9974-EE","Detalle":"Leigh","Precio de compra":30,"Precio de venta":54,"Peso":160342},
{"Codigo":"7579-EE","Detalle":"Waldo","Precio de compra":5,"Precio de venta":53,"Peso":466146},
{"Codigo":"9679-EE","Detalle":"Hilt","Precio de compra":26,"Precio de venta":62,"Peso":8968},
{"Codigo":"1342-EE","Detalle":"Cari","Precio de compra":21,"Precio de venta":66,"Peso":436881},
{"Codigo":"8695-EE","Detalle":"Viv","Precio de compra":17,"Precio de venta":98,"Peso":279420},
{"Codigo":"3996-EE","Detalle":"Parke","Precio de compra":19,"Precio de venta":50,"Peso":324014},
{"Codigo":"2000-EE","Detalle":"Harv","Precio de compra":3,"Precio de venta":67,"Peso":62046}]
cantidad_de_productos = [0,0,0,0,0,0,0,0,0,0]



class Producto ():
    def __init__(self, codigo:str, detalle:str, usd_compra: int, usd_venta: int, peso: int, cantidad: int) -> None:
        self.codigo = codigo
        self.detalle = detalle
        self.usd_compra = usd_compra
        self.usd_venta = usd_venta
        self.peso = peso
        self.cantidad = cantidad 
        
    def __str__(self) -> str:
            return self.codigo

    def alta(self, lista: list, lista_paralela:list):
        print("Ingrese los siguientes datos:")
        codigo_nnnn = get_int_rango_reintentos("Ingresar parte numerica del codigo: ", "ERROR, reintente", 1000,9999,-1)
        codigo_xx = get_string("Ingresar parte alfabetica del codigo: ", 2,2)
        self.codigo = str(f"{str(codigo_nnnn)}-{codigo_xx} ").upper()
        #validar con expresiones regulares
        self.detalle = str(input("Nombre del producto: ")).capitalize()
    
        self.usd_compra = get_int_rango_reintentos("Ingrese precio de compra: ","ERROR, reintente", 0, 100, -1)
        self.usd_venta = get_int_rango_reintentos("Ingrese precio de venta: ","ERROR, reintente", 0, 100, -1)
        self.peso = get_int_rango_reintentos("Ingrese peso en gramos: ","ERROR, reintente", 0, 1000000, -1)
        self.cantidad = 0
        lista.append({"Codigo": self.codigo,
                    "Detalle": self.detalle,
                    "Precio de compra": self.usd_compra,
                    "Precio de venta": self.usd_venta,
                    "Peso": self.peso,})
        lista_paralela.append(self.cantidad)
        print(list(lista))
        print(list(lista_paralela))
        return print(f"El alta del producto fue realizada correctamente con los siguientes datos: \n\tCodigo: {self.codigo}\n\tDetalle: {self.detalle}\n\tPrecio de compra(USD): {self.usd_compra}\n\tPrecio de venta(USD): {self.usd_venta}\n\tPeso: {self.peso}")


    def mostrar_lista(self, lista: list, lista_paralela:list):
        print("[CODIGO] \t[DETALLE] \t[PRECIO COMPRA]  \t[PRECIO VENTA] \t[CANTIDAD EN INVENTARIO]")
        for i in range(len(lista)):
            print(f"{lista[i]["Codigo"]} \t {lista[i]["Detalle"]} \t\t {lista[i]["Precio de compra"]} \t\t\t {lista[i]["Precio de venta"]} \t\t {lista_paralela[i]}")


    def baja(self, lista: list, lista_paralela: list):
        Producto.mostrar_lista(self, lista, lista_paralela)
        borrar = input("¿Que desea borrar? CODIGO = ")
        contador = 0
        while borrar != str(lista[contador]["Codigo"]):
            contador = contador + 1
        lista.pop(contador)
        lista_paralela.pop(contador)
        


    def modificacion(self, lista: list, lista_paralela:list):
        Producto.mostrar_lista(self,lista, lista_paralela)
        modificar = input("¿Que desea modificar? CODIGO = ")
        contador = 0
        while modificar != str(lista[contador]["Codigo"]):
            contador = contador + 1
        print("Que dato desea modificar?")
        modificables = list(lista[0].keys())
        modificar_dato = menu(modificables)
        match modificar_dato:
            case 1:
                codigo_nnnn = get_int_rango_reintentos("Ingresar parte numerica del codigo: ", "ERROR, reintente", 1000,9999,-1)
                codigo_xx = get_string("Ingresar parte alfabetica del codigo: ", 2,2)
                nuevo_dato = str(f"{str(codigo_nnnn)}-{codigo_xx} ").upper()
                lista[contador]["Codigo"] = nuevo_dato
                print("INFORMACION ACTUALIZADA, PARA CHEQUEAR PRESIONE 'MOSTRAR DATOS' EN MENU")
            case 2:
                nuevo_dato = str(input("Nombre del producto: ")).capitalize()
                lista[contador]["Detalle"] = nuevo_dato
                print("INFORMACION ACTUALIZADA, PARA CHEQUEAR PRESIONE 'MOSTRAR DATOS' EN MENU")
            case 3:
                nuevo_dato = get_int_rango_reintentos("Ingrese precio de compra: ","ERROR, reintente", 0, 100, -1)
                lista[contador]["Precio de compra"] = nuevo_dato
                print("INFORMACION ACTUALIZADA, PARA CHEQUEAR PRESIONE 'MOSTRAR DATOS' EN MENU")
            case 4:
                nuevo_dato = get_int_rango_reintentos("Ingrese precio de venta: ","ERROR, reintente", 0, 100, -1)
                lista[contador]["Precio de venta"] = nuevo_dato
                print("INFORMACION ACTUALIZADA, PARA CHEQUEAR PRESIONE 'MOSTRAR DATOS' EN MENU")
            case 5: 
                nuevo_dato = get_int_rango_reintentos("Ingrese peso en gramos: ","ERROR, reintente", 0, 1000000, -1)
                lista[contador]["Peso"] = nuevo_dato
                print("INFORMACION ACTUALIZADA, PARA CHEQUEAR PRESIONE 'MOSTRAR DATOS' EN MENU")

def main():
    while True:
        print ("¿Que desea hacer?")
        eleccion = menu(["Alta de producto", "Baja de producto","Listado de productos", "Modificar producto"])
        match eleccion:
            case 1: 
                Producto.alta(Producto, productos, cantidad_de_productos)
            case 2:
                Producto.baja(Producto, productos, cantidad_de_productos)
            case 3:
                Producto.mostrar_lista(Producto, productos, cantidad_de_productos)
            case 4:
                Producto.modificacion(Producto, productos, cantidad_de_productos)
            case 0:
                break


main()