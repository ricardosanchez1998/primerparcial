from estacionamiento import *
from vehiculo import *
from funcionteca import *
from datetime import *
from __main__ import *
import re
def estacionamiento_leer(path) -> list[Estacionamiento]:
    pass


def estacionamiento_guardar(path) -> None:
    pass

def validar_patente(patente):
    patron = r"^[a-zA-Z]{3}+-[0-9]{3}"
    if re.match(patron, patente):
        return True
    else:
        return False

def alta_vehiculo() -> Vehiculo:
    print("Que desea dar de alta?")
    tipos = ["Auto", "Moto"]
    tipo = menu(tipos)
    patente = str(input("Ingrese la patente: ")).upper()
    while validar_patente(patente) == False:
        patente = str(input("Ingrese la patente: ")).upper()
    vehiculo = Vehiculo(tipos[tipo-1], patente)
    return vehiculo



def alta_estacionamiento(ESTACIONAMIENTOS:list) -> Estacionamiento:
    nombre = str(get_string("Ingrese el nombre del estacionamiento: ", 1,1000)).upper()

    nombres_est =[]

    for i in range (len(ESTACIONAMIENTOS)):
        nombres_est.append(ESTACIONAMIENTOS[i-1].nombre)
    while nombre in nombres_est:
        nombre = str(get_string("[ERROR] ese nombre ya existe, intente otro: ", 1,1000)).upper()
        

    cant_parcelas_autos = get_int_rango_reintentos("Ingrese la cantidad de parcelas para autos: ", "Error, reintente: ", 0,1000,-1)
    cant_parcelas_motos = get_int_rango_reintentos("Ingrese la cantidad de parcelas para motos: ", "Error, reintente: ", 0,1000,-1)
    coste_hora_auto = get_float_rango_reintentos("Ingrese el precio por hora de auto: ", "Error, reintente: ", 0,1000,-1)
    coste_hora_moto = get_float_rango_reintentos("Ingrese el precio por hora de moto: ", "Error, reintente: ", 0,1000,-1)
    
    est = Estacionamiento(nombre, cant_parcelas_autos, cant_parcelas_motos, coste_hora_auto, coste_hora_moto)
    
    """ESTACIONAMIENTOS.append({"id": nombre,
                            "Parcelas para autos": cant_parcelas_autos,
                            "Parcelas para motos": cant_parcelas_motos,
                            "Costo por hora auto": coste_hora_auto,
                            "Costo por hora moto": coste_hora_moto})"""

    print("Su estacionamiento fue dado de alta correctamente")
    return est


def grabar_log(path: str, msj: str):
    #Formato: [Patente: XXX-NNN] [Hora ingreso: DD-MM-YYYY HH:MM] [Hora egreso: DD-MM-YYYYHH:MM] [Importe]
    pass

def menu_estacionamiento (lista: list[Estacionamiento]):
    i=0
    while i < len(lista):
        print (f"[{i+1}] {lista[i].nombre}")
        i+=1

    return get_int_rango_reintentos ("\n\t[OPCION]: ", "[ERROR]", 1, len (lista), -1)

def iterar(Estacionamiento: Estacionamiento):
    auxiliar = []
    for j in Estacionamiento.autos:
        auxiliar.append(j["objeto"])
    for j in Estacionamiento.motos:
        auxiliar.append(j["objeto"])
    return auxiliar

def iterar_patentes(Estacionamiento: Estacionamiento):
    auxiliar = []
    for j in Estacionamiento.autos:
        auxiliar.append(j["objeto"].patente)
    for j in Estacionamiento.motos:
        auxiliar.append(j["objeto"].patente)
    return auxiliar






# MAIN
def punto_1(ESTACIONAMIENTOS: list) -> bool:
    estacionamiento_nuevo = alta_estacionamiento(ESTACIONAMIENTOS)
    ESTACIONAMIENTOS.append(estacionamiento_nuevo)
    return True
def punto_2(ESTACIONAMIENTOS: list) -> bool:
    print("En que estacionamiento se dara de alta el vehiculo?")
    eleccion_estacionamiento = menu_estacionamiento(ESTACIONAMIENTOS)
    vehiculo_ingresado = alta_vehiculo()
    match vehiculo_ingresado.tipo:
        case "Auto":
            ESTACIONAMIENTOS[eleccion_estacionamiento-1].autos.append({"objeto": vehiculo_ingresado,
                                                                        "hora_ingreso": vehiculo_ingresado.hora_ingreso})       
            ESTACIONAMIENTOS[eleccion_estacionamiento-1].cant_parcelas_autos -= 1
        case "Moto":
            ESTACIONAMIENTOS[eleccion_estacionamiento-1].motos.append({"objeto": vehiculo_ingresado,
                                                                        "hora_ingreso": vehiculo_ingresado.hora_ingreso})
            ESTACIONAMIENTOS[eleccion_estacionamiento-1].cant_parcelas_motos -= 1
    return True
def punto_3(ESTACIONAMIENTOS: list) -> bool:
    eleccion_estacionamiento = menu_estacionamiento(ESTACIONAMIENTOS)
    tipos = ["Auto", "Moto"]
    eleccion_tipo = menu(tipos)
    if eleccion_tipo == 1:
        eleccion_auto = menu(ESTACIONAMIENTOS[eleccion_estacionamiento-1].autos)#["objeto"].patente)
        vehiculo_baja = ESTACIONAMIENTOS[eleccion_estacionamiento-1].autos.pop(eleccion_auto-1)
        ESTACIONAMIENTOS[eleccion_estacionamiento-1].cant_parcelas_autos += 1
        costo = ESTACIONAMIENTOS[eleccion_estacionamiento-1].coste_hora_auto

    else:
        eleccion_moto = menu(ESTACIONAMIENTOS[eleccion_estacionamiento-1].motos)
        vehiculo_baja = ESTACIONAMIENTOS[eleccion_estacionamiento-1].motos.pop(eleccion_moto-1)
        ESTACIONAMIENTOS[eleccion_estacionamiento-1].cant_parcelas_motos += 1
        costo = ESTACIONAMIENTOS[eleccion_estacionamiento-1].coste_hora_moto

    hora_ingreso = vehiculo_baja["hora_ingreso"]
    hora_egreso = datetime.now()
    estadia = hora_egreso - hora_ingreso
    estadia_minutos = estadia.total_seconds()/60
    costo_por_minutos = costo/60
    precio = costo_por_minutos * estadia_minutos
    ESTACIONAMIENTOS[eleccion_estacionamiento-1].recaudacion += precio
    return True    
def punto_4(ESTACIONAMIENTOS: list) -> bool:
    eleccion_estacionamiento = menu_estacionamiento(ESTACIONAMIENTOS)
    tipos = ["\tAuto", "\tMoto"]
    print("MODIFICAR EL COSTO POR HORA DE: ")
    eleccion_tipo = menu(tipos)
    if eleccion_tipo == 1:
        ESTACIONAMIENTOS[eleccion_estacionamiento-1].coste_hora_auto = get_float_rango_reintentos("Ingrese el nuevo precio por hora de auto: ", "Error, reintente: ", 0,1000,-1)
    else:
        ESTACIONAMIENTOS[eleccion_estacionamiento-1].coste_hora_moto = get_float_rango_reintentos("Ingrese el nuevo precio por hora de moto: ", "Error, reintente: ", 0,1000,-1)
    return True
def punto_5(ESTACIONAMIENTOS: list) -> bool:
    listar_vehiculos = mi_map(iterar, ESTACIONAMIENTOS)
    print(list(listar_vehiculos))
    return True
def punto_6(ESTACIONAMIENTOS: list) -> bool:
    eleccion_estacionamiento = menu_estacionamiento(ESTACIONAMIENTOS)
    aux= iterar_patentes (ESTACIONAMIENTOS[eleccion_estacionamiento-1])
    print(selection_sort(aux))
    return True
def punto_7(ESTACIONAMIENTOS: list) -> bool:
    def sumar(int:int, asd:Estacionamiento):
        aux = int + asd.recaudacion
        return aux
    recaudacion_total = mi_reduce(ESTACIONAMIENTOS,sumar)
    recaudacion_total = round(float(recaudacion_total),2)
    
    print (f"La recaudacion total es de: ${recaudacion_total}")
    return True
def punto_8(ESTACIONAMIENTOS: list) -> bool:
    def comprobar_estadia(veh:Vehiculo):
        estadia = datetime.now() - veh.hora_ingreso
        estadia_en_minutos = estadia.total_seconds()/60
        if estadia_en_minutos > 60:
            return True

    for i in ESTACIONAMIENTOS:
        estacionamiento_actual = i
        autos_mayores = mi_filter(iterar(estacionamiento_actual), comprobar_estadia)
        print(list(autos_mayores))

    return True   
def punto_9() -> bool:
    pass
def punto_10() -> bool:
    pass

