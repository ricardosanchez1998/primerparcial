from vehiculo import *
from datetime import *
class Estacionamiento:
    autos = []
    motos = []
    recaudacion = 0

    def __init__(self, nombre: str, cant_parcelas_autos: int, cant_parcelas_motos: int, coste_hora_auto: float, coste_hora_moto: float) -> None:
        # Constructor de clase.
        self.nombre = nombre
        self.cant_parcelas_autos = cant_parcelas_autos
        self.cant_parcelas_motos = cant_parcelas_motos
        self.coste_hora_auto = coste_hora_auto
        self.coste_hora_moto = coste_hora_moto
        self.autos = [{"objeto": Vehiculo("Auto","AUT-170"),"hora_ingreso": datetime.now()}, {"objeto": Vehiculo("Auto","AUT-073"),"hora_ingreso": datetime.now()}]
        self.motos = [{"objeto": Vehiculo("Moto","MOT-170"),"hora_ingreso": datetime.now()}, {"objeto": Vehiculo("Moto","MOT-074"),"hora_ingreso": datetime.now()}]
        self.recaudacion = 0

    def __str__(self) -> str:
        # Mostrara toda la informacion del estacionamiento. [CANT MOTOS] [CANT AUTOS][RECAUDACION DEL DIA].
        return str(f"[CANT MOTOS]\t[CANT AUTOS]\t[RECAUDACION DEL DIA]\n{len(Estacionamiento.autos)}\t{len(Estacionamiento.motos)}\t{Estacionamiento.recaudacion}")
    
    def __repr__(self) -> str:
        return f"{self.nombre}"
    
    def __len__(self) -> int:
        # Devuelve la recaudacion con el formato float, con dos numero despues de la coma.
        self.recaudacion = float(self.recaudacion)
        return round(self.recaudacion,2)