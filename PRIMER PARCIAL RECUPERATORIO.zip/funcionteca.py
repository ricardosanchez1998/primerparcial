
def get_int (msj: str):
    return int(input(msj))

def get_float (msj: str):
    return float(input(msj))

def get_int_rango_reintentos (msj: str, msj_error: str, min: int, max: int, reintentos: int | None = None)  -> int | None:

    while reintentos is None or reintentos > 0 or reintentos == -1:
        numero = get_int(msj)
        retorno = None

        if numero >= min and numero <= max:
            retorno = numero
            break
        else: 
            match reintentos:
                case None:
                    break
                case -1: #Para repetir el error hasta ingresar correctamente
                    print(msj_error)
                case _: 
                    print (msj_error)
                    reintentos -= 1

    return retorno

def get_float_rango_reintentos (msj: str, msj_error: str, min: int, max: int, reintentos: int | None = None)  -> float | None:

    while reintentos is None or reintentos > 0 or reintentos == -1:
        numero = get_float(msj)
        retorno = None

        if numero >= min and numero <= max:
            retorno = numero
            break
        else: 
            match reintentos:
                case None:
                    break
                case -1: #Para repetir el error hasta ingresar correctamente
                    print(msj_error)
                case _: 
                    print (msj_error)
                    reintentos -= 1

    return retorno

def menu_principal(opciones: list) -> int:
    i=0
    while i < len(opciones):
        print (f"[{i+1}] {opciones[i]}")
        i+=1

    print ("\n[0] SALIR")
    return get_int_rango_reintentos ("\n\t[OPCION]: ", "[ERROR]", 0, len (opciones), -1)

def menu(opciones: list) -> int:
    i=0
    while i < len(opciones):
        print (f"[{i+1}] {opciones[i]}")
        i+=1

    return get_int_rango_reintentos ("\n\t[OPCION]: ", "[ERROR]", 1, len (opciones), -1)


def get_string (msj: str, min: int, max: int) -> str | None:
    
    aux = input(msj)
    if validar_solo_alfabeticos(aux, min,max) == True:
        return aux

    return None
    
def validar_solo_alfabeticos (cadena:str, min: int, max: int,) -> bool:
    if cadena.isalpha() == True:
        if len(cadena) >= min and len(cadena) <= max:
            return True
    
    return False


def calcular_promedio(lista: list):
    suma = 0
    for elemento in lista:
        suma += elemento
    return suma / len(lista)

def busqueda_lineal(lista, elemento):
    for i in range (len(lista)):
        if lista [i] == elemento:
            return i
    return None

def selection_sort(lista):
    # Tomo un elemento de la lista
    for i in range(len(lista)-1): 
        # En el mejor de los casos, el elemento mas chico esta en el indice i
        indice_del_minimo = i
        # Recorro el resto de la lista para buscar si hay un valor mas chico
        for j in range( i+1, len(lista)): 
            # Si encuentro un valor mas chicos, guardo su indice
            if lista[indice_del_minimo] > lista[j]:
                indice_del_minimo = j
        # Guardo el valor mas chico al principio de la lista
        aux = lista[i]
        lista[i] = lista[indice_del_minimo]
        lista[indice_del_minimo] = aux
    return lista

def filtrar_numeros_positivos(lista):
    lista_filtrada = list()

    for elemento in lista:
        if elemento > 0:
            lista_filtrada.append(elemento)

    return lista_filtrada

def filtrar_numeros_pares(lista):
    lista_filtrada = list()

    for elemento in lista:
        if elemento % 2 == 0:
            lista_filtrada.append(elemento)

    return lista_filtrada

def es_par(numero: int)-> int:
    if numero % 2 == 0:
        return numero


def mi_map(funcion, lista:list)->list:
    aux = []
    for i in lista:
        aux.extend (funcion(i))
    return aux


def mi_reduce(lista:list,funcion):
    acumulador = 0
    for i in range (len(lista)):
        acumulador = funcion(acumulador, lista [i])  

    return acumulador

def mi_filter(lista:list, funcion):
    aux = []
    for i in lista:
        if funcion(i) == True:
            aux.append(i)
    return aux

def get_fecha() -> str:
    print("Ingrese fecha: ")
    aaaa = get_int_rango_reintentos("\tIngrese año: ", "ERROR, reintente: ", 1, 2099, -1)
    mm = get_int_rango_reintentos("\tIngrese mes: ", "ERROR, reintente", 1, 12, -1)
    match mm:
        case 1,3,5,7,8,10,12:
            dd = get_int_rango_reintentos("\tIngresese dia: ", "ERROR, reintente", 1, 32, -1)
        case 2:
            dd = get_int_rango_reintentos("\tIngresese dia: ", "ERROR, reintente", 1, 30, -1)
        case _:
            dd = get_int_rango_reintentos("\tIngresese dia: ", "ERROR, reintente", 1, 31, -1)
    
    """aaaa = str(aaaa)
    while len(aaaa) != 4:
        aaaa."""

    fecha = str(dd)+"/"+str(mm)+"/"+str(aaaa)
    return fecha

"""
data = [{'id': '10', 'first_name': 'Brandy', 'last_name': 'Eskrigge', 'email': 'beskrigge0@ocn.ne.jp', 'gender': 'Male', 'ip_address': '212.198.72.53'}, {'id': '2', 'first_name': 'Abby', 'last_name': 'Crambie', 'email': 'acrambie1@cnet.com', 'gender': 'Male', 'ip_address': '157.214.36.196'}, {'id': '3', 'first_name': 'Rachelle', 'last_name': 'Bremeyer', 'email': 'rbremeyer2@addthis.com', 'gender': 'Female', 'ip_address': '33.151.66.102'}, {'id': '4', 'first_name': 'Silvan', 'last_name': 'Riccione', 'email': 'sriccione3@craigslist.org', 'gender': 'Male', 'ip_address': '153.48.198.165'}, {'id': '5', 'first_name': 'Gare', 'last_name': 'Glas', 'email': 'gglas4@bloglines.com', 'gender': 'Male', 'ip_address': '217.117.177.91'}, {'id': '6', 'first_name': 'Cathleen', 'last_name': 'Sclanders', 'email': 'csclanders5@pbs.org', 'gender': 'Female', 'ip_address': '98.144.88.47'}, {'id': '7', 'first_name': 'Iona', 'last_name': 'Powdrell', 'email': 'ipowdrell6@barnesandnoble.com', 'gender': 'Female', 'ip_address': '192.183.117.141'}, {'id': '8', 'first_name': 'Pavel', 'last_name': 'Gameson', 'email': 'pgameson7@kickstarter.com', 'gender': 'Male', 'ip_address': '198.197.15.167'}, {'id': '9', 'first_name': 'Giulio', 'last_name': 'Simonou', 'email': 'gsimonou8@patch.com', 'gender': 'Male', 'ip_address': '123.39.132.157'}, {'id': '1', 'first_name': 'Jonas', 'last_name': 'Mattheis', 'email': 'jmattheis9@pagesperso-orange.fr', 'gender': 'Male', 'ip_address': '5.133.4.227'}]



import csv

listilla=[]
def importar_csv(path, lista:list):
    with open(path, mode='r', newline='') as file:
        leer = csv.DictReader(file, delimiter=',')
        for fila in leer:
            lista.append(fila)
            #print(fila)

def exportar_csv(path, lista:list[dict]):
    with open(path, mode='w', newline='') as file:
        for i in lista:
            escribir = csv.DictWriter(file, lista[i].keys)
            escribir.writeheader()
            escribir.writerow(lista)
        #for key in lista:
        #    escribir.writerow([key])

exportar_csv("MOCK_EJEMPLO.csv",data)
importar_csv("MOCK_EJEMPLO.csv",listilla)

#importar_csv("MOCK_EJEMPLO.csv", listilla)
print(list(listilla))


Desarrollar 6 funciones:
1 - leer_txt(path, modo)
2 - escribir_txt(path, modo, data)
3 - leer_json(path, modo)
4 - escribir_json(path, modo, data)
5- leer_csv(path, modo)
6 - escribir_csv(path, modo, data) 

import csv
import json

#path = "MOCK_EJEMPLO.json"
#data = [{{"id":11,
          "first_name":"Mav2",
          "last_name":"Kin32t",
          "email":"mkinzasdett0@multiply.com",
          "gender":"Female",
          "ip_address":"50.215.146.252"}
},
{
        "id":12,
        "first_name":"Mav2",
        "last_name":"Kin32t",
        "email":"mkinzasdett0@multiply.com",
        "gender":"Female",
        "ip_address":"50.215.146.252"
},
{
        "id":13,
        "first_name":"Mav2",
        "last_name":"Kin32t",
        "email":"mkinzasdett0@multiply.com",
        "gender":"Female",
        "ip_address":"50.215.146.252"
}]

def leer_json(path, encabezado:str):
    with open(path, 'r') as file:
        archivo = json.load(file)
        for item in archivo:
            print(item[encabezado])


#leer_json(path, "email")

def escribir_json(path, data):
    with open(path, 'w') as file:
        json.dump(data, file, indent=4)

#escribir_json(path, data)
"""