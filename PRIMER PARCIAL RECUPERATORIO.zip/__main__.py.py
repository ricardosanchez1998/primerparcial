from union import *
from datetime import datetime
path_estacionamientos = 'db_estacionamientos.json'
ESTACIONAMIENTOS = []#estacionamiento_leer(path_estacionamientos)
ESTACIONAMIENTOS.append(Estacionamiento("MIRANDA", 100,50,60000,500.32))
ESTACIONAMIENTOS.append(Estacionamiento("CHACABUCO", 100,50,3000,2000))



'''
[MENU]
[1] Nuevo estacionamiento
[2] Ingreso de vehículo
[3] Egreso de vehículo
[4] Modificar costes por hora de vehiculos
[5] Listar vehículos estacionados (map)
[6] Listar vehículos ordenados por patente (descendente)
[7] Recaudación total de todos los estacionamientos (reduce)
[8] Listar vehiculos filtrados por cantidad de minutos estacionados que superen los 60 min (filter)
[9] Guardar archivo 'db_estacionamientos.csv'
[10] Ver log de ingresos y egresos
'''

def main():
    while True:
        print ("¿Que desea hacer?")
        eleccion = menu_principal(["Nuevo estacionamiento", "Ingreso de vehículo","Egreso de vehículo", "Modificar costes por hora de vehiculos", "Listar vehiculos", "Ordenar vehiculos", "Recaudacion total", "Vehiculos con estadia de mas de una hora"])
        match eleccion:
            case 1: 
                punto_1(ESTACIONAMIENTOS)
            case 2:
                punto_2(ESTACIONAMIENTOS)
            case 3:
                punto_3(ESTACIONAMIENTOS)
            case 4:
                punto_4(ESTACIONAMIENTOS)
            case 5:
                punto_5(ESTACIONAMIENTOS)
            case 6:
                punto_6(ESTACIONAMIENTOS)
            case 7:
                punto_7(ESTACIONAMIENTOS)
            case 8:
                punto_8(ESTACIONAMIENTOS)
            case 9:
                punto_9(ESTACIONAMIENTOS)
            case 10:
                punto_10(ESTACIONAMIENTOS)
            case 0:
                break


main()