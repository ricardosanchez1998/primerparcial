from datetime import datetime
class Vehiculo:

    hora_ingreso = datetime.now()


    def __init__(self, tipo: str, patente: str) -> None:
        # Constructor de clase.
        self.tipo = tipo
        self.patente = patente
        self.hora_ingreso = datetime.now()


    def __str__(self) -> str:
        # Devuelve la patente.
        return str(self.patente)

    def __repr__(self) -> str:
        return f"{self.patente}"

    def __len__(self) -> int:
        # Devuelve la cantidad de minutos de diferencia entre hora_ingreso y hora_actual.
        pass


